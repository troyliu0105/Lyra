"use strict";
(() => {
  // src/early/modhub-rule-patch.ts
  function rewriteModHubRules(source, helper) {
    const normalized = source.replaceAll("\r\n", "\n");
    const start = normalized.indexOf("    function inferRequiredDependencies(");
    const end = normalized.indexOf("\n    function getRequiredDependencies(", start);
    if (start < 0 || end <= start || normalized.includes("__swDependencyRules")) return;
    const infer = normalized.slice(start, end);
    const blockStart = infer.indexOf("                const name = ");
    const blockEnd = infer.indexOf("\n                if (!explicit.test(clause)", blockStart);
    const escape = infer.split("\n").find((line) => line.includes("const escapePattern ="));
    if (blockStart < 0 || blockEnd <= blockStart || !escape) return;
    const block = infer.slice(blockStart, blockEnd);
    if ((block.match(/new RegExp\(/g) ?? []).length !== 3) return;
    const setup = `${helper}
const __swDependencyCompile = alias => {
${escape}
${block.replaceAll("entry.alias", "alias")}
return [explicit, framework, requiredAs];
};
const __swDependencyRules = SwModHubDependencyRules.createRuleCache(__swDependencyCompile);
`;
    const replacement = "                const [explicit, framework, requiredAs] = names.size <= __swDependencyRules.limit ? __swDependencyRules.get(entry.alias) : __swDependencyCompile(entry.alias);";
    const rewritten = normalized.slice(0, start) + setup + infer.slice(0, blockStart) + replacement + infer.slice(blockEnd) + normalized.slice(end);
    return source.includes("\r\n") ? rewritten.replaceAll("\n", "\r\n") : rewritten;
  }

  // src/early/modhub-performance.ts
  var targetSha = "4082ed4ba8e0d3d64035bf24bcf34376f70572ba0f4cefcce26f9cb0c7e3a648";
  var isRecord = (value) => !!value && typeof value === "object";
  async function afterModLoad(_boot, _zip, info) {
    if (!isRecord(info) || info.name !== "ModHub" || info.version !== "1.9.2" || !isRecord(info.cache)) return;
    const cache = info.cache.scriptFileItems;
    if (!isRecord(cache) || !Array.isArray(cache.items) || !(cache.map instanceof Map)) return;
    const matches = cache.items.filter((item2) => isRecord(item2) && item2.name === "javascript/modhub-market.js");
    const item = matches[0];
    if (matches.length !== 1 || !isRecord(item) || typeof item.content !== "string" || cache.map.get(item.name) !== item) return;
    const original = item.content;
    try {
      if (!globalThis.crypto?.subtle) return;
      const bytes = new TextEncoder().encode(original);
      const hash = [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map((byte) => byte.toString(16).padStart(2, "0")).join("");
      if (hash !== targetSha || item.content !== original || info.cache.scriptFileItems !== cache || cache.map.get(item.name) !== item || !cache.items.includes(item)) return;
      const rewritten = rewriteModHubRules(original, '"use strict";\nvar SwModHubDependencyRules = (() => {\n  var __defProp = Object.defineProperty;\n  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;\n  var __getOwnPropNames = Object.getOwnPropertyNames;\n  var __hasOwnProp = Object.prototype.hasOwnProperty;\n  var __export = (target, all) => {\n    for (var name in all)\n      __defProp(target, name, { get: all[name], enumerable: true });\n  };\n  var __copyProps = (to, from, except, desc) => {\n    if (from && typeof from === "object" || typeof from === "function") {\n      for (let key of __getOwnPropNames(from))\n        if (!__hasOwnProp.call(to, key) && key !== except)\n          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });\n    }\n    return to;\n  };\n  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);\n\n  // src/early/dependency-rule-cache.ts\n  var dependency_rule_cache_exports = {};\n  __export(dependency_rule_cache_exports, {\n    createRuleCache: () => createRuleCache\n  });\n  function createRuleCache(compile) {\n    const entries = /* @__PURE__ */ new Map(), limit = 1024, maxAliasLength = 256;\n    let builds = 0, hits = 0, evictions = 0, bypasses = 0;\n    return {\n      limit,\n      get(alias) {\n        const found = entries.get(alias);\n        if (found) {\n          entries.delete(alias);\n          entries.set(alias, found);\n          hits++;\n          return found;\n        }\n        const patterns = compile(alias);\n        builds++;\n        if (patterns.some((pattern) => pattern.global || pattern.sticky)) throw Error("Stateful rules cannot be cached");\n        if (alias.length > maxAliasLength) {\n          bypasses++;\n          return patterns;\n        }\n        if (entries.size === limit) {\n          entries.delete(entries.keys().next().value);\n          evictions++;\n        }\n        entries.set(alias, patterns);\n        return patterns;\n      },\n      clear() {\n        entries.clear();\n      },\n      stats: () => ({ builds, hits, evictions, bypasses, size: entries.size, limit, maxAliasLength })\n    };\n  }\n  return __toCommonJS(dependency_rule_cache_exports);\n})();\n');
      if (rewritten) item.content = rewritten;
    } catch (error) {
      console.warn("[Soft & Wet] ModHub rule cache skipped; upstream source retained.", error);
    }
  }
  try {
    const manager = Reflect.get(window, "modSC2DataManager");
    if (isRecord(manager) && typeof manager.getModLoadController === "function") {
      const controller = manager.getModLoadController();
      if (isRecord(controller) && typeof controller.addLifeTimeCircleHook === "function") {
        controller.addLifeTimeCircleHook("DoLGameUI.ModHubDependencyRules", { afterModLoad });
      }
    }
  } catch (error) {
    console.warn("[Soft & Wet] ModHub rule cache unavailable; upstream loader retained.", error);
  }
})();
