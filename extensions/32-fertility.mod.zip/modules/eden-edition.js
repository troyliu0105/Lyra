;(() => {
	"use strict";
	window.EdenEdition = Object.freeze({ kind: "lite", usesLargeArtwork: false });
})();
